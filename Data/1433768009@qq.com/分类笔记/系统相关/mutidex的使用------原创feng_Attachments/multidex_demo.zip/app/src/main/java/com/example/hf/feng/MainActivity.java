package com.example.hf.feng;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

import com.excelliance.open.MultiDexUtils;

import java.io.IOException;
import java.util.List;

/**
 * Created by HF on 2016/7/27.
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            List<String> externalDexClasses = MultiDexUtils.getLoadedExternalDexClasses(getApplicationContext());
            if(externalDexClasses!=null){
                for (int i = 0; i <externalDexClasses.size() ; i++) {
                    Log.d("feng", "onCreate "+i+": "+ externalDexClasses.get(i));
                }
            }
        }catch (Exception e) {
            Log.d("feng", ".error");
            e.printStackTrace();
        }
        setContentView(R.layout.activity_main);
    }
}
