package com.example.hf.feng;

import android.content.Context;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;


public class MyApplication extends MultiDexApplication {//multidex: 继承MultiDexApplication即可
    public void onCreate() {
        super.onCreate();
    }

}


/**
 * multidex: 如果已经继承了其他Application
 */


//public class MyApplication extends OtherApplication {
//    public void onCreate() {
//        super.onCreate();
//    }
//
//    @Override
//    protected void attachBaseContext(Context base) {// multidex: 重写attachBaseContext
//        super.attachBaseContext(base);
//        MultiDex.install(this);
//    }
//}


